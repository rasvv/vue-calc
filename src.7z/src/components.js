import Modal from '@/components/Modal.vue';
export default function install(Vue) {
  Vue.component('Modal', Modal);
}
